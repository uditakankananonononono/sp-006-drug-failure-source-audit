# DOC-2-069 R0 closeout - historical-source/identifiability negative

## Verdict
R0 closes before lock and before outcome modeling. The current ClinicalTrials.gov API passed field and numerical metadata feasibility, but the required historical status-as-of source could not be acquired and versioned through the official AACT/CTTI download surface within the fixed source gate. No current-status proxy, guessed snapshot URL, internal 403 history route, or third-party repackaging was used.

## What passed
ClinicalTrials.gov API v2.0.5, data timestamp 2026-09-22 09:00:04, exposed stable NCT IDs and the required current fields. A deterministic 10,000-record interventional-drug metadata sample found 1,504 candidate later trials with observed earlier same-normalized-entity records and 254 current terminated/withdrawn/suspended statuses, above the numerical minima. This was a schema/count audit only, not an outcome analysis.

## What failed
The public API has no public record-history endpoint for past status reconstruction. The web application's internal history route returned HTTP 403. Official AACT documentation states that it keeps recent daily snapshots and first-of-month archives, with flat-file snapshots around 2.3 GB. During the bounded attempt, the official snapshot pages redirected to account sign-in or returned the site's 404 page in this environment. Effective September 15, 2026, the AACT site states that an account is required to access/download data. No connected authenticated AACT account or direct official snapshot download URL was available. Therefore two dated snapshot bytes could not be downloaded, hashed, schema-versioned, or tested.

Without snapshot bytes, the required 50-NCT status-as-of fixture and the >=500/100/100 cohort after an 18-month preceding-snapshot rule cannot be proven. Current status cannot substitute because it may reflect changes after the index start and would create future leakage.

## Useful negative
The intervention portfolio question is numerically plausible but not identifiable from the current API alone. A future round requires authenticated official AACT access and at least two dated flat-file snapshots, followed by a metadata-only status-as-of fixture before any lock or outcome inspection.

## Boundary
Termination/withdrawal/suspension is an administrative registry outcome, not biological failure. No efficacy, mechanism, patient, or deployment claim is supported.
