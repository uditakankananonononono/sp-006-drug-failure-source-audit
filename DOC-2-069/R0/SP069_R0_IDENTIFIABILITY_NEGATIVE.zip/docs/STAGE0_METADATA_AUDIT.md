# DOC-2-069 R0 metadata/API audit

**Retrieval:** ClinicalTrials.gov API v2.0.5, data timestamp 2026-09-22 09:00:04, retrieved 2026-09-22 15:07 UTC. Official endpoint: https://clinicaltrials.gov/api/v2/studies . Official API documentation: https://clinicaltrials.gov/data-api/api .

## Schema and sample
A deterministic 10,000-record metadata sample of interventional drug studies confirmed stable NCT IDs and availability of overall status, why-stopped text, phase, drug intervention names/types, lead sponsor, conditions, enrollment, start/completion dates, and first/last posted update dates. Nonmissing counts were: status 10,000; start 9,893; completion 9,629; last update posted 10,000; phase 10,000 (including explicit NA arrays); enrollment 9,515; sponsor/conditions/drug name 10,000. Why-stopped text was present for 1,100 records, consistent with its conditional nature.

Frozen normalization uses NFKC, casefolding, parenthetical removal, a fixed list of salt tokens, non-alphanumeric replacement, and whitespace collapse. Multi-drug trials map to sorted unique entities and remain flagged. The sample contained 10,127 normalized entities and 1,504 with at least two trials.

A metadata-only temporal candidate screen found 1,504 later trials starting 2015-2020 with an earlier same-entity trial in the sample, including 254 terminated/withdrawn/suspended records. This exceeds the numerical minima of 500 later trials, 100 non-completions, and 100 entities under commodity compute. These are feasibility counts, not modeled outcomes.

## Identifiability blocker
The public API supplies current records, not an official public history endpoint usable for past status-as-of reconstruction. Current `lastUpdatePostDate` cannot establish when a prior trial first became terminated/withdrawn/suspended. Using current status for a later index trial would leak future information. The internal web history route returned 403 and is not a valid source.

AACT historical snapshots appear to be the appropriate bulk route, but no versioned snapshot series was acquired in this run. Accordingly Stage 0 is **conditional/source-incomplete**, not cleared for modeling. Before any outcome lock, acquire and hash official/AACT snapshots bracketing trial starts, reconstruct status change dates, and verify no-future-information assertions on a sample. If that cannot be done, close R0 as an identifiability negative.

## Boundary
A termination is an administrative registry status, not proof of biological failure. Why-stopped text is audit context only and index-trial why-stopped text must never be a predictor. The intended artifact is review prioritization, not drug efficacy, causal mechanism, patient advice, or deployment.
