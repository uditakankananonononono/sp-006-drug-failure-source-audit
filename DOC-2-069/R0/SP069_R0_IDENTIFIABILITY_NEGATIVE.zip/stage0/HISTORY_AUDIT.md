# Historical-state availability audit

The public ClinicalTrials.gov API v2 exposes current structured records and stable NCT IDs, including status dates and posted/update dates. Its public OpenAPI surface does not expose a record-history endpoint. The web application has an internal history route, but unauthenticated direct calls returned HTTP 403 and are not an acceptable analysis source.

Therefore exact `status/change date precedes index start` features cannot be built from current API records alone without risking future information. A separate official/bulk historical snapshot source is required. AACT provides ClinicalTrials.gov relational snapshots and archive downloads, but this run did not yet acquire/version a historical snapshot series. R0 source feasibility can pass only conditionally on pinning those snapshots and proving change-date reconstruction before outcomes.
