import requests,json,time,re,unicodedata,hashlib,collections,datetime
from pathlib import Path
W=Path('/home/sandbox/sp069_r0');url='https://clinicaltrials.gov/api/v2/studies';token=None;rows=[];pages=[];t0=time.time();base={'format':'json','pageSize':1000,'query.term':'AREA[StudyType]INTERVENTIONAL AND AREA[InterventionType]DRUG','countTotal':'true'}
for page in range(10):
 params=dict(base)
 if token:params['pageToken']=token
 r=requests.get(url,params=params,timeout=60);r.raise_for_status();x=r.json();pages.append({'url':r.url,'n':len(x['studies'])});rows.extend(x['studies']);token=x.get('nextPageToken')
 if not token:break
print('studies',len(rows),'total',x.get('totalCount'),flush=True)
def get(d,path,default=None):
 for k in path.split('.'):
  if not isinstance(d,dict) or k not in d:return default
  d=d[k]
 return d
def norm(s):
 s=unicodedata.normalize('NFKC',s).casefold();s=re.sub(r'\([^)]*\)',' ',s);s=re.sub(r'\b(hydrochloride|sodium|potassium|acetate|phosphate|sulfate|sulphate|mesylate|besylate|hydrate)\b',' ',s);s=re.sub(r'[^a-z0-9]+',' ',s);return ' '.join(s.split())
a=[]
for s in rows:
 p=s.get('protocolSection',{});ints=get(p,'armsInterventionsModule.interventions',[]) or [];dr=[i.get('name') for i in ints if i.get('type')=='DRUG' and i.get('name')];ents=sorted(set(norm(q) for q in dr if norm(q)));a.append({'nct':get(p,'identificationModule.nctId'),'status':get(p,'statusModule.overallStatus'),'why':get(p,'statusModule.whyStopped'),'start':get(p,'statusModule.startDateStruct.date'),'completion':get(p,'statusModule.completionDateStruct.date'),'first_post':get(p,'statusModule.studyFirstPostDateStruct.date'),'last_update_post':get(p,'statusModule.lastUpdatePostDateStruct.date'),'phase':get(p,'designModule.phases',[]) or [],'enrollment':get(p,'designModule.enrollmentInfo.count'),'sponsor':get(p,'sponsorCollaboratorsModule.leadSponsor.name'),'conditions':get(p,'conditionsModule.conditions',[]) or [],'drug_names':dr,'entities':ents})
fields=['status','start','completion','last_update_post','phase','enrollment','sponsor','conditions','drug_names','entities'];complete={f:sum(bool(r[f]) for r in a) for f in fields};status=collections.Counter(r['status'] for r in a);entities=collections.Counter(e for r in a for e in r['entities']);non={'TERMINATED','WITHDRAWN','SUSPENDED'};cand=[]
for r in a:
 if not r['start'] or not r['entities']:continue
 try:y=int(r['start'][:4])
 except:continue
 if 2015<=y<=2020 and any(q['start'] and q['start']<r['start'] and set(q['entities'])&set(r['entities']) for q in a):cand.append(r)
out={'retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'api_endpoint':url,'api_version':json.load(open(W/'stage0/api_version.json')),'query':base['query.term'],'sample_pages':pages,'sample_n':len(a),'reported_total':x.get('totalCount'),'field_nonmissing':complete,'statuses':dict(status),'why_stopped_nonmissing':sum(bool(r['why']) for r in a),'normalized_entity_count':len(entities),'entities_with_2plus_trials':sum(v>=2 for v in entities.values()),'candidate_later_2015_2020_with_observed_prior_in_sample':len(cand),'candidate_noncompletions':sum(r['status'] in non for r in cand),'normalization':'NFKC, casefold, remove parentheticals, remove frozen salt tokens, nonalnum->space, collapse whitespace; multi-drug trials map to sorted unique entities and are flagged multi-entity','runtime_seconds':time.time()-t0,'sample_sha256':hashlib.sha256(json.dumps(a,sort_keys=True).encode()).hexdigest()}
(W/'stage0/METADATA_AUDIT.json').write_text(json.dumps(out,indent=2));(W/'stage0/SAMPLE_METADATA.json').write_text(json.dumps(a));print(json.dumps(out,indent=2))
